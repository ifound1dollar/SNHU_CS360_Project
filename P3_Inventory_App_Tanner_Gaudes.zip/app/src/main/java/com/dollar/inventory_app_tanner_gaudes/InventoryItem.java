package com.dollar.inventory_app_tanner_gaudes;

import java.io.Serializable;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "inventory_table")
public class InventoryItem implements Serializable {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String itemName;
    private int price;
    private int quantity;


    public InventoryItem(String itemName, int price, int quantity) {
        this.itemName = itemName;
        this.price = price;
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;

        //If quantity now <= 0, show notification.
        if (quantity <= 0) InventoryApp.getInstance().showZeroQuantityNotification(itemName, quantity);
    }
}
