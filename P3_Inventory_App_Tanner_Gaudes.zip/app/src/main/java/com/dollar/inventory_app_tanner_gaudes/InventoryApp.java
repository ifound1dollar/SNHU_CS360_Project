package com.dollar.inventory_app_tanner_gaudes;

import android.app.Application;
import android.content.Context;
import android.content.pm.PackageManager;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class InventoryApp extends Application {
    private static InventoryApp instance;

    public static InventoryApp getInstance() {
        return instance;
    }

    public Context getContext() {
        return instance.getApplicationContext();
    }

    private InventoryRepository inventoryRepository;
    public InventoryRepository getInventoryRepository() { return inventoryRepository; }

    private UsersRepository usersRepository;
    public UsersRepository getUsersRepository() { return usersRepository; }


    @Override
    public void onCreate() {
        instance = this;
        inventoryRepository = new InventoryRepository(this);
        usersRepository = new UsersRepository(this);

        super.onCreate();
    }

    public void showZeroQuantityNotification(String itemName, int itemQuantity) {

        NotificationCompat.Builder builder = new NotificationCompat.Builder(instance.getContext(), "channel_quantity")
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("Zero quantity")
                .setContentText(String.format("%s quantity has dropped to %d.", itemName, itemQuantity))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(instance.getContext());
        if (ActivityCompat.checkSelfPermission(instance.getContext(), android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            //Log.d(TAG, "showZeroQuantityNotification: NO PERMISSION");
            return;
        }

        //Log.d(TAG, "showZeroQuantityNotification: THIS");
        managerCompat.notify(0, builder.build());
    }
}
