package com.dollar.inventory_app_tanner_gaudes;

import static android.content.ContentValues.TAG;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ActivityItemDetails extends AppCompatActivity {
    public static final String INVENTORY_ITEM_KEY = "item";
    public static final String INVENTORY_INDEX_KEY = "index";

    TextView nameView;
    TextView priceView;
    TextView quantityView;
    InventoryItem item;
    int itemIndex;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_details);

        nameView = findViewById(R.id.nameTextView);
        priceView = findViewById(R.id.priceTextView);
        quantityView = findViewById(R.id.quantityTextView);

        //Get InventoryItem and its index from Intent's extras added by ActivityItemList.
        item = (InventoryItem)getIntent().getSerializableExtra(INVENTORY_ITEM_KEY);
        itemIndex = getIntent().getIntExtra(INVENTORY_INDEX_KEY, 0);
        if (item != null) {
            //Log.d(TAG, "onCreate: Successfully got inventory item from parent.");

            //Set TextView fields.
            nameView.setText(item.getItemName());
            float price = ((float)item.getPrice()) / 100;
            priceView.setText(String.format("%.2f", price));
            quantityView.setText(Integer.toString(item.getQuantity()));
        }
    }

    public void onEditQuantityButtonClick(View view) {
        //Create Dialog object for notification dialog and setup.
        Dialog editDialog = new Dialog(this);
        editDialog.setContentView(R.layout.dialog_edit_quantity);
        editDialog.setCancelable(false);

        //Setup Confirm and Cancel buttons with their respective click listeners.
        Button buttonConfirm = editDialog.findViewById(R.id.buttonYes);
        Button buttonCancel = editDialog.findViewById(R.id.buttonNo);

        //Get quantity number EditText and set its default value to current quantity.
        EditText numEditText = editDialog.findViewById(R.id.editTextNumber);
        numEditText.setText(Integer.toString(item.getQuantity()));

        buttonConfirm.setOnClickListener(view1 -> {
            //CONFIRM HERE
            //Log.d(TAG, "onItemLongClick: Clicked Confirm button in edit quantity dialog.");

            //Get quantity from numEditText and set actual field with it.
            int quantity;
            try {
                quantity = Integer.parseInt(numEditText.getText().toString());
            } catch (NumberFormatException e) {
                quantity = item.getQuantity();
            }
            item.setQuantity(quantity);
            quantityView.setText(Integer.toString(item.getQuantity()));

            //Update corresponding item in InventoryRepository then dismiss dialog.
            InventoryApp.getInstance().getInventoryRepository().update(item);
            editDialog.dismiss();
        });
        buttonCancel.setOnClickListener(view2 -> {
            //CANCEL HERE
            //Log.d(TAG, "onItemLongClick: Clicked Cancel button in edit quantity dialog.");

            editDialog.dismiss();
        });

        //FINALLY, show dialog.
        editDialog.show();
    }
}