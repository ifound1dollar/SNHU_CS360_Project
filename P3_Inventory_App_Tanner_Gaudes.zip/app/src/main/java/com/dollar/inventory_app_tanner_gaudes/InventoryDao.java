package com.dollar.inventory_app_tanner_gaudes;

import androidx.lifecycle.LiveData;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;


@androidx.room.Dao
public interface InventoryDao {
    @Insert
    void insert(InventoryItem item);

    @Update
    void update(InventoryItem item);

    @Delete
    void delete(InventoryItem item);

    @Query("DELETE FROM inventory_table")
    void deleteAllItems();

    @Query("SELECT * FROM inventory_table ORDER BY itemName ASC")
    List<InventoryItem> getAllItems();
}
