package com.dollar.inventory_app_tanner_gaudes;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

import android.Manifest;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ActivityItemList extends AppCompatActivity {
    GridView itemGridView;

    List<InventoryItem> itemsList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_item_list);

        itemGridView = findViewById(R.id.itemsGridView);
        itemsList = InventoryApp.getInstance().getInventoryRepository().getAllItems();

        //Create adapter and pass it temp ArrayList, then set itemGridView to it to populate the grid.
        InventoryItemAdapter adapter = new InventoryItemAdapter(this,
                itemsList);
        itemGridView.setAdapter(adapter);

        //Set listener to fire method when a CardItem is clicked.
        itemGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                startItemDetailsActivity(adapter, i);
            }
        });


        //Set long click listener to fire method when CardItem is long clicked.
        Dialog deleteDialog = new Dialog(this);
        itemGridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                //Setup dialog basic attributes.
                deleteDialog.setContentView(R.layout.dialog_delete);
                deleteDialog.setCancelable(false);    //require button press

                //Use InventoryItem at clicked position to dynamically set dialog text.
                InventoryItem item = itemsList.get(i);
                ((TextView)deleteDialog.findViewById(R.id.deleteItemHeader))
                        .setText(getResources().getString(R.string.dialog_delete_header, item.getItemName()));

                //Setup Yes and No buttons with their respective click listeners.
                Button dialogButtonYes = deleteDialog.findViewById(R.id.buttonYes);
                Button dialogButtonNo = deleteDialog.findViewById(R.id.buttonNo);
                dialogButtonYes.setOnClickListener(view1 -> {
                    //DELETE ITEM HERE

                    //Remove item from database.
                    InventoryItem toDelete = InventoryApp.getInstance().getInventoryRepository().getAllItems().get(i);
                    InventoryApp.getInstance().getInventoryRepository().delete(toDelete);

                    deleteDialog.dismiss();
                    //Log.d(TAG, "onItemLongClick: Clicked Yes button in delete dialog.");

                    //Reload activity to force update UI, skipping transition animations (TEMPORARY SOLUTION).
                    Intent intent = new Intent(ActivityItemList.this, ActivityItemList.class);
                    finish();
                    overridePendingTransition(0, 0);
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                });
                dialogButtonNo.setOnClickListener(view2 -> {
                    //CANCEL HERE
                    deleteDialog.dismiss();
                    //Log.d(TAG, "onItemLongClick: Clicked No button in delete dialog.");
                });

                //FINALLY, show dialog and return true.
                deleteDialog.show();
                return true;
            }
        });
    }

    @Override
    protected void onPostResume() {
        //Will reload components when this Activity is resumed.
        super.onPostResume();

        itemsList = InventoryApp.getInstance().getInventoryRepository().getAllItems();
        InventoryItemAdapter adapter = new InventoryItemAdapter(this,
                itemsList);
        itemGridView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    private void startItemDetailsActivity(InventoryItemAdapter adapter, int index) {
        //Get InventoryItem at the position.
        InventoryItem item = InventoryApp.getInstance().getInventoryRepository().getAllItems().get(index);

        //Start new intent and pass SERIALIZABLE corresponding InventoryItem.
        Intent itemDetailsIntent = new Intent(this, ActivityItemDetails.class);
        itemDetailsIntent.putExtra(ActivityItemDetails.INVENTORY_ITEM_KEY, item);
        itemDetailsIntent.putExtra(ActivityItemDetails.INVENTORY_INDEX_KEY, index);
        startActivity(itemDetailsIntent);

        //Log.d(TAG, "onItemClick: Method called with value " + index);
    }

    @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
    public void onNotifButtonClick(View view) {
        //Ask to enable notifications if not already, else create notification channel.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            //Ask for notification permission.
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 101);
        } else {
            //Create notification channel.
            CharSequence name = InventoryApp.getInstance().getContext().getString(R.string.channel_name);
            String desc = InventoryApp.getInstance().getContext().getString(R.string.channel_desc);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel channel = new NotificationChannel("channel_quantity", name, importance);
            channel.setDescription(desc);

            //Create NotificationManager and register channel.
            NotificationManager notificationManager = (NotificationManager)getApplicationContext()
                    .getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(channel);
        }
    }

    public void onAddItemButtonClick(View view) {
        //Log.d(TAG, "onAddItemButtonClick: Method called in ActivityItemList.");

        //Create ActivityAddItem intent, then start the Activity.
        Intent addItemIntent = new Intent(this, ActivityAddItem.class);
        startActivity(addItemIntent);
    }
}