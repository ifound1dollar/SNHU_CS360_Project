package com.dollar.inventory_app_tanner_gaudes;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ActivityAddItem extends AppCompatActivity {
    EditText nameText;
    EditText priceText;
    EditText quantityText;
    Button confirmButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        nameText = findViewById(R.id.nameEditText);
        priceText = findViewById(R.id.priceEditText);
        quantityText = findViewById(R.id.quantityEditText);
        confirmButton = findViewById(R.id.buttonAddItem);

        //Add text changed listeners for all fields to dynamically enable/disable confirm button.
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                confirmButton.setEnabled(checkFieldsNotEmpty());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        priceText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                confirmButton.setEnabled(checkFieldsNotEmpty());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        quantityText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                confirmButton.setEnabled(checkFieldsNotEmpty());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private boolean checkFieldsNotEmpty() {
        //Returns whether all fields are NOT empty (true if all have some text).
        return !nameText.getText().toString().isEmpty() && !priceText.getText().toString().isEmpty()
                && !quantityText.getText().toString().isEmpty();
    }

    public void onAddItemConfirmButtonClick(View view) {
        //Log.d(TAG, "onAddItemButtonClick: Method called in ActivityAddItem.");

        //Create new InventoryItem from fields.
        String name = nameText.getText().toString();
        int price;
        try {
            price = (int)(Float.parseFloat(priceText.getText().toString()) * 100);
        } catch (NumberFormatException e) {
            price = 0;
        }
        int quantity;
        try {
            quantity = Integer.parseInt(quantityText.getText().toString());
        } catch (NumberFormatException e) {
            quantity = 0;
        }
        InventoryItem item = new InventoryItem(name, price, quantity);

        //Add new item to database, then return.
        InventoryApp.getInstance().getInventoryRepository().insert(item);
        super.onBackPressed();
    }
}