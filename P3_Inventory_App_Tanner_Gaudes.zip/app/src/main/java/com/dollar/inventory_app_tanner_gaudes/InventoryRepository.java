package com.dollar.inventory_app_tanner_gaudes;

import static android.content.ContentValues.TAG;

import android.app.Application;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import androidx.lifecycle.LiveData;

import java.util.ArrayList;
import java.util.List;

public class InventoryRepository {
    private InventoryDao dao;
    private List<InventoryItem> allItems;

    public InventoryRepository(Context context) {
        InventoryDatabase database = InventoryDatabase.getInstance(context);
        dao = database.Dao();

        //TEMP
        //dao.deleteAllItems();
        //TEMP

        allItems = dao.getAllItems();

        //If null or empty, add starter items.
        if (allItems == null || allItems.isEmpty()) {
            Log.d(TAG, "InventoryRepository: Database was empty.");
            dao.insert(new InventoryItem("Apple", 159, 0));
            //dao.insert(new InventoryItem("Pear", 168, 0));
            //dao.insert(new InventoryItem("Paper Towel", 698, 0));
            //dao.insert(new InventoryItem("Pizza", 500, 0));
            //dao.insert(new InventoryItem("Notebook", 249, 0));

            allItems = dao.getAllItems();
        }
    }

    public void insert(InventoryItem item) {
        new InsertItemAsyncTask(dao).execute(item);
    }

    public void update(InventoryItem item) {
        new UpdateItemAsyncTask(dao).execute(item);
    }

    public void delete(InventoryItem item) {
        new DeleteItemAsyncTask(dao).execute(item);
    }

    public void deleteAllItems() {
        new DeleteAllItemsAsyncTask(dao).execute();
    }

    public List<InventoryItem> getAllItems() {
        return dao.getAllItems();
    }



    private static class InsertItemAsyncTask extends AsyncTask<InventoryItem, Void, Void> {
        private InventoryDao dao;

        private InsertItemAsyncTask(InventoryDao dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(InventoryItem... items) {
            dao.insert(items[0]);
            return null;
        }
    }

    private static class UpdateItemAsyncTask extends AsyncTask<InventoryItem, Void, Void> {
        private InventoryDao dao;

        private UpdateItemAsyncTask(InventoryDao dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(InventoryItem... items) {
            dao.update(items[0]);
            return null;
        }
    }

    private static class DeleteItemAsyncTask extends AsyncTask<InventoryItem, Void, Void> {
        private InventoryDao dao;

        private DeleteItemAsyncTask(InventoryDao dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(InventoryItem... items) {
            dao.delete(items[0]);
            return null;
        }
    }

    private static class DeleteAllItemsAsyncTask extends AsyncTask<InventoryItem, Void, Void> {
        private InventoryDao dao;

        private DeleteAllItemsAsyncTask(InventoryDao dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(InventoryItem... items) {
            dao.deleteAllItems();
            return null;
        }
    }
}
