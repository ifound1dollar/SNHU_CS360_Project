package com.dollar.inventory_app_tanner_gaudes;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;
import java.util.List;

public class ActivityLogin extends AppCompatActivity {
    EditText usernameEditText;
    EditText passwordEditText;
    Button addUserButton;
    Button loginButton;

    //Define TextWatcher used by BOTH EditText fields to dynamically enable/disable buttons.
    TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            //encapsulate in try-catch block to ensure no null pointer exceptions
            try {
                //IF both fields have text, enable buttons, ELSE disable
                boolean enable = !usernameEditText.getText().toString().isEmpty()
                        && !passwordEditText.getText().toString().isEmpty();
                
                addUserButton.setEnabled(enable);
                loginButton.setEnabled(enable);
            } catch (Exception e) {
                Log.e(TAG, "onTextChanged: ", e);
            }
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };
    

    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        addUserButton = findViewById(R.id.buttonAddUser);
        loginButton = findViewById(R.id.buttonLogin);
        
        //Add text changed listeners for EditTexts to dynamically enable and disable buttons.
        usernameEditText.addTextChangedListener(textWatcher);
        passwordEditText.addTextChangedListener(textWatcher);   //same watcher for both
    }
    
    public void onAddUserButtonClick(View view) {
        Log.d(TAG, "onAddUserButtonClick: Method called.");

        //Get all users from database (NOT AT ALL SECURE BTW) and store temporarily.
        List<User> users = InventoryApp.getInstance().getUsersRepository().getAllUsers();

        //If this username does NOT exist in any of the Users from the database.
        if (users.stream().noneMatch(p -> p.getUsername().equals(usernameEditText.getText().toString()))) {
            //Create new user and insert in database.
            User temp = new User(usernameEditText.getText().toString(), passwordEditText.getText().toString());
            InventoryApp.getInstance().getUsersRepository().insert(temp);

            //Show acknowledgement toast.
            String toastString = String.format("Added new user with username %s.", usernameEditText.getText().toString());
            Toast toast = Toast.makeText(this, toastString, Toast.LENGTH_SHORT);
            toast.show();
        } else {
            Toast toast = Toast.makeText(this, "Username already exists.", Toast.LENGTH_SHORT);
            toast.show();
        }

        passwordEditText.setText("");
    }
    
    public void onLoginButtonClick(View view) {
        Log.d(TAG, "onLoginButtonClick: Method called.");

        //Get all users from database (NOT AT ALL SECURE BTW) and store temporarily.
        List<User> users = InventoryApp.getInstance().getUsersRepository().getAllUsers();

        //If this username exists in any of the Users from the database.
        if (users.stream().anyMatch(p -> p.getUsername().equals(usernameEditText.getText().toString()))) {
            //If this password also matches, login.
            if (users.stream().anyMatch(p -> p.getPassword().equals(passwordEditText.getText().toString()))) {
                Intent intent = new Intent(this, ActivityItemList.class);
                //finish();
                startActivity(intent);
                return;
            }
        }

        Toast toast = Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT);
        toast.show();
        passwordEditText.setText("");
    }
}