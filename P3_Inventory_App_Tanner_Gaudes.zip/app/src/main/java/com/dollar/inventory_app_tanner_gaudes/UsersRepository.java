package com.dollar.inventory_app_tanner_gaudes;

import static android.content.ContentValues.TAG;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import java.util.List;

public class UsersRepository {
    private UsersDao dao;
    private List<User> allUsers;

    public UsersRepository(Context context) {
        UsersDatabase database = UsersDatabase.getInstance(context);
        dao = database.Dao();

        //TEMP
        //dao.deleteAllUsers();
        //TEMP

        allUsers = dao.getAllUsers();

        //If null or empty, add starter User.
        if (allUsers == null || allUsers.isEmpty()) {
            Log.d(TAG, "UsersRepository: Database was empty.");
            //dao.insert(new User("username", "password"));

            allUsers = dao.getAllUsers();
        }
    }

    public void insert(User item) {
        new InsertItemAsyncTask(dao).execute(item);
    }

    public void update(User item) {
        new UpdateItemAsyncTask(dao).execute(item);
    }

    public void delete(User item) {
        new DeleteItemAsyncTask(dao).execute(item);
    }

    public void deleteAllItems() {
        new DeleteAllItemsAsyncTask(dao).execute();
    }

    public List<User> getAllUsers() {
        return dao.getAllUsers();
    }



    private static class InsertItemAsyncTask extends AsyncTask<User, Void, Void> {
        private UsersDao dao;

        private InsertItemAsyncTask(UsersDao dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(User... users) {
            dao.insert(users[0]);
            return null;
        }
    }

    private static class UpdateItemAsyncTask extends AsyncTask<User, Void, Void> {
        private UsersDao dao;

        private UpdateItemAsyncTask(UsersDao dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(User... users) {
            dao.update(users[0]);
            return null;
        }
    }

    private static class DeleteItemAsyncTask extends AsyncTask<User, Void, Void> {
        private UsersDao dao;

        private DeleteItemAsyncTask(UsersDao dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(User... users) {
            dao.delete(users[0]);
            return null;
        }
    }

    private static class DeleteAllItemsAsyncTask extends AsyncTask<User, Void, Void> {
        private UsersDao dao;

        private DeleteAllItemsAsyncTask(UsersDao dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(User... users) {
            dao.deleteAllUsers();
            return null;
        }
    }
}
