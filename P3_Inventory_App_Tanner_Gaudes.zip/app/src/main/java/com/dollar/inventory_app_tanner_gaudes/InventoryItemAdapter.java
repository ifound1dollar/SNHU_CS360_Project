package com.dollar.inventory_app_tanner_gaudes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class InventoryItemAdapter extends ArrayAdapter<InventoryItem> {
    public InventoryItemAdapter(@NonNull Context context, List<InventoryItem> inventoryItems) {
        super(context, 0, inventoryItems);
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            //If null, inflate all items to be displayed in GridView.
            listItemView = LayoutInflater.from(getContext())
                    .inflate(R.layout.card_item_grid, parent, false);
        }

        InventoryItem item = getItem(position);
        TextView itemTextView = listItemView.findViewById(R.id.itemNameTextView);
        ImageView itemImageView = listItemView.findViewById(R.id.itemImageView);

        itemTextView.setText(item.getItemName());
        itemImageView.setImageResource(R.drawable.ic_launcher_foreground);

        return listItemView;
    }

    public InventoryItem getItemAtPosition(int position) {
        return getItem(position);
    }
}
